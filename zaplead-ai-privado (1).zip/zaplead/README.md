# ZapLead AI (privado)
1. **Supabase**: crie o projeto e rode `supabase/schema.sql` no SQL Editor.
2. **Authentication > Sign In / Providers**: desligue *Allow new users to sign up* (o trigger do schema já bloqueia outros e-mails).
3. **Authentication > Users > Add user**: e-mail `mahclara156@gmail.com`, senha definida ali, *Auto Confirm*. A senha nunca fica no código.
4. **Authentication > URL Configuration**: Site URL = seu domínio; Redirect URLs = `https://SEU-DOMINIO/login` (necessário para "Esqueci minha senha").
5. **Vercel**: importe a pasta e cadastre as variáveis de `.env.example` (SUPABASE_URL, SUPABASE_ANON_KEY, ADMIN_EMAIL, ANTHROPIC_API_KEY). Sem service role key.
6. `vercel --prod` e acesse `/login`.

Busca: OpenStreetMap/Overpass (sem chave). Cobertura em cidades pequenas pode ser parcial e muitos negócios não têm contato mapeado; use "Novo lead manual" para completar. Atribuição: © colaboradores do OpenStreetMap (ODbL).
Segurança: RLS com `is_admin()`, APIs validam JWT + e-mail, chaves só no servidor. `/dashboard` é HTML estático sem dados ou segredos.
