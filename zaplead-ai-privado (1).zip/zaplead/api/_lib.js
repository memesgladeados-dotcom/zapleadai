import { createClient } from '@supabase/supabase-js';
// Valida o JWT do Supabase e exige o e-mail do administrador. Usa o token do usuário (RLS continua valendo).
export async function auth(req, res) {
  const t = (req.headers.authorization || '').replace(/^Bearer /, '');
  if (!t) { res.status(401).json({ error: 'Não autorizado' }); return null; }
  const sb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY, { global: { headers: { Authorization: 'Bearer ' + t } } });
  const { data, error } = await sb.auth.getUser(t);
  if (error || !data.user || data.user.email?.toLowerCase() !== (process.env.ADMIN_EMAIL || '').toLowerCase()) { res.status(401).json({ error: 'Não autorizado' }); return null; }
  return { sb, user: data.user };
}
