// Só valores públicos por design (URL e anon key do Supabase). Nenhum segredo.
export default (req, res) => res.json({ url: process.env.SUPABASE_URL, anon: process.env.SUPABASE_ANON_KEY, admin: process.env.ADMIN_EMAIL,
  flags: { osm: true, ai: !!process.env.ANTHROPIC_API_KEY } });
