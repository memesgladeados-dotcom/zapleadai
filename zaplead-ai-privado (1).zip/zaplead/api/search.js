import { auth } from './_lib.js';
// Fonte: OpenStreetMap via Overpass API (dados abertos, licença ODbL, exige atribuição). Só tags públicas; nada é inferido.
const OK = /^[\p{L}\s.'-]{2,50} - [A-Z]{2}$/u;
const Q = {
  'Lojas': ['["shop"]["shop"!~"supermarket|convenience|greengrocer|hairdresser|beauty"]'],
  'Malharias': ['["shop"~"clothes|fabric|boutique|tailor|wool"]', '["craft"~"tailor|knitter"]'],
  'Restaurantes': ['["amenity"~"restaurant|fast_food"]'],
  'Pizzarias': ['["cuisine"~"pizza"]'],
  'Barbearias': ['["shop"="hairdresser"]["name"~"barb",i]'],
  'Salões': ['["shop"~"hairdresser|beauty"]'],
  'Clínicas': ['["amenity"~"clinic|doctors|dentist"]', '["healthcare"]'],
  'Academias': ['["leisure"="fitness_centre"]'],
  'Mercados': ['["shop"~"supermarket|convenience|greengrocer|butcher"]'],
  'Hotéis/Pousadas': ['["tourism"~"hotel|guest_house|hostel|motel|chalet"]'],
  'Prestadores de serviços': ['["office"]', '["craft"]', '["shop"~"car_repair|laundry|copyshop"]'],
  'Outros': ['["amenity"~"pharmacy|bank|fuel|veterinary"]'],
};
const EP = ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter'];
const c = (v, n = 200) => (v ? String(v).trim().slice(0, n) || null : null);
const ig = v => { if (!v) return null; const m = String(v).match(/instagram\.com\/([\w.]{1,30})/i) || String(v).match(/^@?([\w.]{1,30})$/); return m ? '@' + m[1] : null; };
const web = v => { v = c(v); if (!v) return null; v = /^https?:\/\//i.test(v) ? v : 'https://' + v; return /^https?:\/\/[^\s]+$/i.test(v) ? v : null; };
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const a = await auth(req, res); if (!a) return;
  const { city, segment } = req.body || {};
  if (!OK.test(city || '') || !Q[segment]) return res.status(400).json({ error: 'Dados inválidos' });
  const name = city.split(' - ')[0];
  const q = `[out:json][timeout:25];area["name"="${name}"]["boundary"="administrative"]["admin_level"="8"]->.a;(${Q[segment].map(f => `nwr${f}(area.a);`).join('')});out center tags 150;`;
  let j = null;
  for (const ep of EP) {
    try {
      const r = await fetch(ep, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'ZapLeadAI/1.0 (' + process.env.ADMIN_EMAIL + ')' }, body: 'data=' + encodeURIComponent(q), signal: AbortSignal.timeout(27000) });
      if (r.ok) { j = await r.json(); break; }
    } catch { /* tenta o próximo servidor */ }
  }
  if (!j) return res.status(502).json({ error: 'A fonte de dados não respondeu. Tente de novo em instantes.' });
  const seen = new Set();
  const results = (j.elements || []).filter(e => e.tags?.name).map(e => { const t = e.tags;
    return { place_id: `osm:${e.type}/${e.id}`, name: c(t.name, 120), segment, city,
      address: c([t['addr:street'], t['addr:housenumber'], t['addr:suburb']].filter(Boolean).join(', ')),
      lat: e.lat ?? e.center?.lat ?? null, lng: e.lon ?? e.center?.lon ?? null,
      phone: c(t.phone || t['contact:phone'], 40), whatsapp: c(t['contact:whatsapp'], 40), instagram: ig(t['contact:instagram'] || t.instagram),
      email: /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(t.email || t['contact:email'] || '') ? c(t.email || t['contact:email']) : null,
      website: web(t.website || t['contact:website']), source: 'OpenStreetMap (ODbL)', source_ref: `https://www.openstreetmap.org/${e.type}/${e.id}` }; })
    .filter(r => !seen.has(r.place_id) && seen.add(r.place_id));
  await a.sb.from('searches').insert({ city, segment, query: `${segment} em ${city}`, result_count: results.length });
  res.json({ results });
}
