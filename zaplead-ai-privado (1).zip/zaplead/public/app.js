/* Camada real do ZapLead AI: Supabase (RLS) + /api. Sem chaves secretas aqui. */
let sb;const STK=['novo','contatar','em_conversa','interessado','negociacao','cliente','sem_interesse'],fd=x=>new Date(x).toLocaleDateString('pt-BR');
const fromDb=r=>({id:r.id,pid:r.place_id,name:r.name,seg:r.segment,city:r.city,loc:r.address,lat:r.lat,lng:r.lng,tel:r.phone,ref:r.source_ref,wa:r.whatsapp,ig:r.instagram,mail:r.email,site:r.website,src:r.source,st:Math.max(0,STK.indexOf(r.status)),last:r.last_contact_at?fd(r.last_contact_at):null,found:fd(r.created_at),note:'',saved:true,msg:''});
async function api(p,b){const{data:{session}}=await sb.auth.getSession();if(!session){location.replace('/login');return{error:'Sessão expirada'}}
try{const r=await fetch(p,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+session.access_token},body:JSON.stringify(b)});return await r.json()}catch{return{error:'Falha de conexão'}}}
function refresh(){if(S.view=='radar')drawRes();else if(S.view!='ai')render();if($('#drawer').classList.contains('o')&&S.drawer)openLead(S.drawer.id)}
async function saveLead(l){if(l.saved)return;const{data,error}=await sb.from('business_leads').insert({place_id:l.pid,name:l.name,segment:l.seg,city:l.city,address:l.loc,lat:l.lat,lng:l.lng,phone:l.tel,whatsapp:l.wa,instagram:l.ig,email:l.mail,website:l.site,source:l.src,source_ref:l.ref,status:'novo'}).select().single();
if(error)return toast(error.code=='23505'?'Este lead já está salvo.':'Erro ao salvar o lead.');
Object.assign(l,{id:data.id,saved:true});S.leads.unshift(l);await sb.from('activities').insert({lead_id:l.id,type:'created',detail:'Lead salvo a partir de '+l.src});toast('Lead salvo no CRM.');refresh()}
async function setStatus(l){if(!l.saved){l.st=0;return toast('Salve o lead antes de mudar o status.')}
const p={status:STK[l.st]};if(l.st>1)p.last_contact_at=new Date().toISOString();
const{error}=await sb.from('business_leads').update(p).eq('id',l.id);if(error)return toast('Erro ao atualizar.');
if(p.last_contact_at)l.last=fd(p.last_contact_at);await sb.from('activities').insert({lead_id:l.id,type:'status',detail:'Status: '+ST[l.st]});toast('Status atualizado.')}
function fit(){if(!S.res.length)return;const g=S.res.filter(l=>l.lat!=null);if(!g.length)return;const a=g.reduce((p,l)=>p+l.lat,0)/g.length,o=g.reduce((p,l)=>p+l.lng,0)/g.length;
let m=.01;g.forEach(l=>m=Math.max(m,Math.abs(l.lat-a),Math.abs(l.lng-o)));G.c=[a,o];G.tla=a;G.tl=o;G.tz=Math.min(600,Math.max(8,150/(m*D)/($('#gl').clientHeight*.44)))}
async function go(){if(S.busy)return;S.busy=true;S.res=[];G.focus(S.city);$('#gb').disabled=true;$('#stx').textContent='ZapLead AI consultando fontes autorizadas...';drawRes();
const r=await api('/api/search',{city:S.city,segment:S.seg});S.busy=false;$('#gb').disabled=false;
if(r.error){$('#stx').textContent=r.error;return drawRes()}
S.res=r.results.map(x=>{const k=S.leads.find(l=>l.pid==x.place_id);return k||{id:'r'+x.place_id,pid:x.place_id,name:x.name||'Não disponível',seg:x.segment,city:x.city,loc:x.address,lat:x.lat,lng:x.lng,tel:x.phone,wa:x.whatsapp,ig:x.instagram,mail:x.email,site:x.website,ref:x.source_ref,src:x.source,st:0,last:null,found:fd(Date.now()),saved:false,msg:''}});
$('#stx').textContent=S.res.length?`${S.res.length} empresas encontradas em ${S.city}.`:'Nenhum resultado para esta busca.';S.nsearch=(S.nsearch||0)+1;fit();drawRes()}
async function ask(t){say('u',t);say('a','Consultando seus leads...');const r=await api('/api/ai',{mode:'chat',message:t});S.chat.pop();say('a',r.error||r.text)}
const _ol=openLead;openLead=function(id){_ol(id);extras(id)};
async function extras(id){const l=find(id);if(!l||!l.saved)return;const[n,a]=await Promise.all([sb.from('notes').select('body,created_at').eq('lead_id',l.id),sb.from('activities').select('detail,created_at').eq('lead_id',l.id).limit(30)]);
const h=[...(n.data||[]).map(x=>[x.created_at,'📝 '+x.body]),...(a.data||[]).map(x=>[x.created_at,x.detail])].sort((p,q)=>q[0].localeCompare(p[0]));
$('#drawer').insertAdjacentHTML('beforeend',`<div class="g" style="margin-top:12px"><h2>Contatos informados por você</h2><p class="mu" style="font-size:12px">Preencha só contatos comerciais públicos ou autorizados.</p><label>WhatsApp</label><input id="xw" value="${esc(l.wa||'')}"><label>Instagram</label><input id="xi" value="${esc(l.ig||'')}"><label>E-mail comercial</label><input id="xm" value="${esc(l.mail||'')}"><p style="margin-top:8px" class="act"><button class="btn" data-a="sc" data-id="${l.id}">Salvar contatos</button><button class="btn" data-a="sn" data-id="${l.id}">Salvar nota</button><button class="btn" data-a="del" data-id="${l.id}">Excluir lead</button></p></div><div class="g" style="margin-top:12px"><h2>Histórico</h2>${h.map(([t,s])=>`<p class="mu" style="margin:6px 0">${new Date(t).toLocaleString('pt-BR')}: ${esc(s)}</p>`).join('')||'<p class="mu">Sem registros.</p>'}</div>`)}
document.addEventListener('click',async e=>{const t=e.target.closest('[data-a]');if(!t)return;const a=t.dataset.a,l=t.dataset.id&&find(t.dataset.id);
if(!['out','sc','sn','gen'].includes(a))return;e.stopImmediatePropagation();
if(a=='out'){await sb.auth.signOut();return location.replace('/login')}
if(!l||!l.saved)return toast('Salve o lead primeiro.');
if(a=='sc'){const w=$('#xw').value.replace(/[^\d+]/g,''),i=$('#xi').value.trim().replace(/^@/,''),m=$('#xm').value.trim();
if(i&&!/^[\w.]{1,30}$/.test(i)||m&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(m)||w.length>16)return toast('Verifique os contatos informados.');
const p={whatsapp:w||null,instagram:i?'@'+i:null,email:m||null};const{error}=await sb.from('business_leads').update(p).eq('id',l.id);if(error)return toast('Erro ao salvar.');
Object.assign(l,{wa:p.whatsapp,ig:p.instagram,mail:p.email});await sb.from('activities').insert({lead_id:l.id,type:'contacts',detail:'Contatos atualizados'});toast('Contatos salvos.');refresh()}
if(a=='sn'){const b=$('#dn').value.trim();if(!b||b.length>2000)return toast('Escreva uma nota (até 2000 caracteres).');const{error}=await sb.from('notes').insert({lead_id:l.id,body:b});if(error)return toast('Erro ao salvar nota.');toast('Nota salva.');openLead(l.id)}
if(a=='gen'){t.disabled=true;const r=await api('/api/ai',{mode:'message',leadId:l.id});if(r.error){t.disabled=false;return toast(r.error)}l.msg=r.text;openLead(l.id)}},true);
(async()=>{try{const c=await(await fetch('/api/config')).json();window.CF=c.flags;sb=supabase.createClient(c.url,c.anon);
const{data:{session}}=await sb.auth.getSession();if(!session||session.user.email.toLowerCase()!==String(c.admin).toLowerCase()){await sb.auth.signOut();return location.replace('/login')}
sb.auth.onAuthStateChange((_,s)=>{if(!s)location.replace('/login')});
const{data,error}=await sb.from('business_leads').select('*').order('created_at',{ascending:false});if(error)toast('Erro ao carregar leads.');
const{count}=await sb.from('searches').select('*',{count:'exact',head:true});S.nsearch=count||0;S.leads.length=0;(data||[]).forEach(r=>S.leads.push(fromDb(r)));$('#shell').style.display='block';render()}catch{location.replace('/login')}})();
/* Extras: exportar CSV, lead manual, excluir lead (LGPD) */
document.addEventListener('click',async e=>{const t=e.target.closest('[data-a]');if(!t)return;const a=t.dataset.a;if(!['csv','add','ms','del'].includes(a))return;e.stopImmediatePropagation();
if(a=='csv'){const q=v=>{v=v==null?'':String(v);if(/^[=+\-@\t\r]/.test(v))v="'"+v;return '"'+v.replace(/"/g,'""')+'"'};
const rows=[['Empresa','Segmento','Cidade','Endereço','Telefone','WhatsApp','Instagram','E-mail','Site','Origem','Status','Encontrado em'],...S.leads.map(l=>[l.name,l.seg,l.city,l.loc,l.tel,l.wa,l.ig,l.mail,l.site,l.src,ST[l.st],l.found])];
const u=URL.createObjectURL(new Blob(['\ufeff'+rows.map(r=>r.map(q).join(',')).join('\n')],{type:'text/csv;charset=utf-8'}));const k=document.createElement('a');k.href=u;k.download='zaplead-leads.csv';k.click();URL.revokeObjectURL(u);return}
if(a=='add'){const o=x=>x.map(v=>`<option>${esc(v)}</option>`).join(''),i=(id,l)=>`<label>${l}</label><input id="n_${id}" maxlength="200">`,d=$('#drawer');
d.innerHTML=`<div style="display:flex;justify-content:space-between"><h2>Novo lead manual</h2><button class="btn" data-a="close" aria-label="Fechar">✕</button></div><p class="mu" style="font-size:12px">Informe só dados comerciais públicos ou autorizados.</p>${i('name','Empresa')}<label>Segmento</label><select id="n_seg">${o(SEGS)}</select><label>Cidade</label><select id="n_city">${o(S.cities)}</select>${i('tel','Telefone')}${i('wa','WhatsApp')}${i('ig','Instagram')}${i('mail','E-mail comercial')}${i('site','Site')}<p><button class="btn pri" data-a="ms" style="margin-top:14px">Salvar lead</button></p>`;d.classList.add('o');return}
if(a=='ms'){const g=id=>$('#n_'+id).value.trim(),name=g('name'),ig=g('ig').replace(/^@/,''),mail=g('mail'),wa=g('wa').replace(/[^\d+]/g,''),site=g('site');
if(!name||ig&&!/^[\w.]{1,30}$/.test(ig)||mail&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mail)||/\s/.test(site))return toast('Verifique os campos.');
const row={name,segment:g('seg'),city:g('city'),phone:g('tel')||null,whatsapp:wa||null,instagram:ig?'@'+ig:null,email:mail||null,website:site?(/^https?:\/\//i.test(site)?site:'https://'+site):null,source:'Cadastro manual',status:'novo'};
const{data,error}=await sb.from('business_leads').insert(row).select().single();if(error)return toast('Erro ao salvar.');
S.leads.unshift(fromDb(data));await sb.from('activities').insert({lead_id:data.id,type:'created',detail:'Lead cadastrado manualmente'});$('#drawer').classList.remove('o');S.drawer=null;toast('Lead salvo.');refresh();return}
if(a=='del'){const l=find(t.dataset.id);if(!l||!l.saved||!confirm('Excluir este lead e todo o histórico? Não dá para desfazer.'))return;
const{error}=await sb.from('business_leads').delete().eq('id',l.id);if(error)return toast('Erro ao excluir.');
S.leads.splice(S.leads.indexOf(l),1);if(l.pid){l.saved=false;l.id='r'+l.pid}$('#drawer').classList.remove('o');S.drawer=null;toast('Lead excluído.');refresh()}},true);
