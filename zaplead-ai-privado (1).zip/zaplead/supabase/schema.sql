-- ZapLead AI: rode no SQL Editor do Supabase.
create extension if not exists pgcrypto;
create or replace function public.admin_email() returns text language sql immutable as $$ select 'mahclara156@gmail.com' $$;
create or replace function public.is_admin() returns boolean language sql stable as $$ select lower(coalesce(auth.jwt()->>'email',''))=public.admin_email() $$;
-- Mesmo que o cadastro público seja ligado por engano, nenhum outro e-mail consegue criar conta.
create or replace function public.only_admin() returns trigger language plpgsql security definer set search_path=public as $$
begin if lower(new.email)<>public.admin_email() then raise exception 'Cadastro não autorizado'; end if; return new; end $$;
drop trigger if exists only_admin on auth.users; create trigger only_admin before insert on auth.users for each row execute function public.only_admin();
create or replace function public.touch() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end $$;

create table public.cities(id uuid primary key default gen_random_uuid(),name text not null,state text not null default 'MG',active boolean default true,created_at timestamptz default now(),updated_at timestamptz default now(),unique(name,state));
create table public.segments(id uuid primary key default gen_random_uuid(),name text unique not null,created_at timestamptz default now(),updated_at timestamptz default now());
create table public.lead_sources(id uuid primary key default gen_random_uuid(),name text unique not null,terms_url text,created_at timestamptz default now(),updated_at timestamptz default now());
create table public.business_leads(id uuid primary key default gen_random_uuid(),user_id uuid not null default auth.uid() references auth.users on delete cascade,
 place_id text,name text not null,segment text,city text,address text,lat double precision,lng double precision,phone text,whatsapp text,instagram text,email text,website text,source text not null,source_ref text,
 status text not null default 'novo' check(status in('novo','contatar','em_conversa','interessado','negociacao','cliente','sem_interesse')),last_contact_at timestamptz,
 created_at timestamptz default now(),updated_at timestamptz default now(),unique(user_id,place_id));
create table public.notes(id uuid primary key default gen_random_uuid(),lead_id uuid not null references public.business_leads on delete cascade,body text not null check(char_length(body)<=2000),created_at timestamptz default now(),updated_at timestamptz default now());
create table public.activities(id uuid primary key default gen_random_uuid(),lead_id uuid not null references public.business_leads on delete cascade,type text not null,detail text,created_at timestamptz default now(),updated_at timestamptz default now());
create table public.searches(id uuid primary key default gen_random_uuid(),user_id uuid not null default auth.uid() references auth.users on delete cascade,city text,segment text,query text,result_count int,created_at timestamptz default now(),updated_at timestamptz default now());
create index on public.business_leads(city,segment);create index on public.business_leads(status);

do $$ declare t text; begin
 foreach t in array array['cities','segments','lead_sources','business_leads','notes','activities','searches'] loop
  execute format('alter table public.%I enable row level security',t);
  execute format('create policy "admin_all" on public.%I for all to authenticated using (public.is_admin()) with check (public.is_admin())',t);
  execute format('create trigger touch before update on public.%I for each row execute function public.touch()',t);
  execute format('revoke all on public.%I from anon',t);
 end loop; end $$;
-- Analytics: calculado a partir de business_leads/activities (view abaixo respeita RLS).
create view public.analytics with (security_invoker=true) as select city,segment,status,count(*) total from public.business_leads group by 1,2,3;
-- lead_contacts: contatos ficam em business_leads (phone/whatsapp/instagram/email); separe em tabela própria se precisar de múltiplos por lead.
